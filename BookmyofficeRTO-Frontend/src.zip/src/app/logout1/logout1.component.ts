import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-logout1',
  templateUrl: './logout1.component.html',
  styleUrls: ['./logout1.component.css']
})
export class Logout1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
