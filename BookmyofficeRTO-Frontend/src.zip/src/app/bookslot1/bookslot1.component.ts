import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-bookslot1',
  templateUrl: './bookslot1.component.html',
  styleUrls: ['./bookslot1.component.css']
})
export class Bookslot1Component implements OnInit {

  constructor() { }

  dates:Date[]=[];

  curr:Date = new Date();
  len=0;
  seldate=" ";
  
  ngOnInit(): void {
    
   
   
    while( this.len<7)
    {
       this.curr.setDate(this.curr.getDate()+1);
       
        
       if(this.curr.getDay()!==0 && this.curr.getDay()!==6)
       {
      
        this.dates.push(new Date(this.curr));
  
         this.len=this.len+1;
  
       }

    }

  }

  sel1()
  {
    console.log(this.seldate)
    
  }
  

  
  
 

}
