import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
export class Dashboard
{
  constructor(public bookingDate:Date ,public totalSeats:Number,public seatsAvailable:Number){}
}
@Injectable({
  providedIn: 'root'
})
export class DashboardService {

constructor(private Http:HttpClient) { }

remainingseats(date:Date)
  {
    return this.Http.get<Number>(`http://localhost:8080/seats/{date}`);
 
  }

}
