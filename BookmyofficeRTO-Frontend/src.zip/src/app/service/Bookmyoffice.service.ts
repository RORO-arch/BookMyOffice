import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from './employee.service';

export class Bookmyoffice{
  constructor(public bookingId:Number,public managerId:Number,
    public employee:Employee,public bookingDate:string,public floorId:Number,public portId:Number ){}
}

@Injectable({
  providedIn: 'root'
})
export class BookmyofficeService {

constructor(private Http:HttpClient) { }

addslot(bookmyoffice:Bookmyoffice){
  const headers = { 'content-type': 'application/json'}
  const body = JSON.stringify(bookmyoffice)
  return this.Http.post<Employee>('http://localhost:8080/addslot',body,{'headers':headers});
}

deleteBooking(id:number){
  return this.Http.delete(`http://localhost:8080/deleteslot/${id}`);
}

retrieveEmployee(id:number){
  return this.Http.get<Employee>(`http://localhost:8080/details/${id}`);
}


}
