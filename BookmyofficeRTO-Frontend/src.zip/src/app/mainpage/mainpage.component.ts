import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mainpage',
  templateUrl: './mainpage.component.html',
  styleUrls: ['./mainpage.component.css']
})
export class MainpageComponent implements OnInit {

  constructor(private router:Router) { }
  empid=0

  ngOnInit(): void {

    this.empid=JSON.parse( sessionStorage.getItem("Id")||'{}')
    //console.log(this.Aemail)
  }

  logOut()
  {
    sessionStorage.clear(); 
    this.router.navigate(['']);
    
  }

}
